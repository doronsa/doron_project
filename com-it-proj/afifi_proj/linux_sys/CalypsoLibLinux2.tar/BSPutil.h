#ifndef BSP_UTIL_H_
#define BSP_UTIL_H_

//void timer_handler (int sig);
void init_timer(void);
void start_timer(long time);
void stop_timer(void);
#endif
