/*
 * demon_util.h
 *
 *  Created on: Apr 4, 2014
 *      Author: doronsa
 */

#ifndef DEMON_UTIL_H_
#define DEMON_UTIL_H_

int K10_Download(void);

#endif /* DEMON_UTIL_H_ */
