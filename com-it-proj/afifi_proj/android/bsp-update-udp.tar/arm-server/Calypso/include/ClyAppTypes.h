#pragma once
#ifndef P_MTR_1020TYP_H
#define P_MTR_1020TYP_H


#endif //P_MTR_1020TYP_H
